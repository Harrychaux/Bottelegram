/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 10.4.20-MariaDB : Database - ingresos_gastos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`ingresos_gastos` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `ingresos_gastos`;

/*Table structure for table `gastos` */

DROP TABLE IF EXISTS `gastos`;

CREATE TABLE `gastos` (
  `id_gasto` int(11) NOT NULL AUTO_INCREMENT,
  `ingresar_gasto` bigint(25) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `fecha` date NOT NULL,
  `id_usuario` varchar(255) NOT NULL,
  PRIMARY KEY (`id_gasto`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `gastos` */

insert  into `gastos`(`id_gasto`,`ingresar_gasto`,`descripcion`,`fecha`,`id_usuario`) values 
(1,20000,'gasolina','2022-05-28','5333152031'),
(2,40000,'cambioaceite','2022-05-29','5333152031'),
(3,30000,'comida','2022-05-28','5333152031'),
(4,170000,'remesa','2022-05-01','5333152031'),
(5,8000,'motopinchada','2022-06-01','5333152031'),
(6,18000,'cine','2022-06-02','5333152031'),
(7,35000,'cargador','2022-05-31','5333152031'),
(8,80500,'helados','2022-06-01','5333152031'),
(9,25000,'gasolina','2022-06-05','5333152031'),
(10,18000,'carne','2022-06-05','5333152031'),
(11,2500,'empanadas','2022-06-05','5333152031'),
(13,4300,'rizadas','2022-07-06','5333152031'),
(14,2800,'chocorramo','2022-06-08','5333152031');

/*Table structure for table `ingresos` */

DROP TABLE IF EXISTS `ingresos`;

CREATE TABLE `ingresos` (
  `id_ingreso` int(11) NOT NULL AUTO_INCREMENT,
  `valor_a_ingresar` bigint(25) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `fecha` date NOT NULL,
  `id_usuario` varchar(255) NOT NULL,
  PRIMARY KEY (`id_ingreso`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

/*Data for the table `ingresos` */

insert  into `ingresos`(`id_ingreso`,`valor_a_ingresar`,`descripcion`,`fecha`,`id_usuario`) values 
(1,3500000,'sueldonetcomunicaciones','2022-05-28','5333152031'),
(2,400000,'jovenesenaccion','2022-05-28','5333152031'),
(5,45000,'fotocopias','2022-06-01','5333152031'),
(6,58000,'efecty','2022-06-02','5333152031');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
